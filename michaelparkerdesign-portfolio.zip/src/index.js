import React from "react";
import ReactDOM from "react-dom";
import App from "./app.js";

// function App() {
//   return (
//     <div className="App">
//       <h1>Welcome to CodeSandbox</h1>
//     </div>
//   );
// }

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
